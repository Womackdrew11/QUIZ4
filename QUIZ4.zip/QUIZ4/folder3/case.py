def convert_to_uppercase(input_string):
    return input_string.upper()
