def calculate_square(number):
    return number ** 2
